package Com;

public class J 
{
	public static void main(String[] args) 
	   {
		  for(int i=1;i<=5;i++)
		  {
			  for(int j=5;i<=j;j--)
			  {
				  System.out.print(" ");
			  }
			  for(int x=1;x<=i;x++)
			  {
				  System.out.print("*");
			  }
			    for(int y=2;y<=i;y++)
			    {
			    System.out.print("*");
		  }
			    System.out.println();
		  
		  }
		  for(int i=1;i<=5;i++)
			 {
				 for(int j=1;j<=i;j++)
				 {
					 System.out.print(" ");
				 }
				 for(int x=5;x>=i;x--)
				 {
					 System.out.print("*");
				 }
				    for(int y=4;y>=i;y--)
				    {
				 
				     System.out.print("*");
				    }
				    System.out.println();
			 }
}
}
