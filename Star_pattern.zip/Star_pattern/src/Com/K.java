package Com;

public class K {
	public static void main(String[] args) 
	{
		for (int i = 1; i <= 5; i++)
		{
			for (int j = 1; j <= i; j++)
			{
				System.out.print("*");
			}
			for (int k = 5; k > i; k--)
			{
				System.out.print(" ");
			}
			for (int k = 5; k > i; k--)
			{
				System.out.print(" ");
			}
			for (int u = 1; u <= i; u++)
			{
				System.out.print("*");
			}

			System.out.println();
		}
		for (int a = 1; a <= 5; a++) 
		{
			for (int b = 4; b >= a; b--) 
			{
				System.out.print("*");
			}
			  for(int m=1;m<=a;m++)
			  {
				  System.out.print(" ");
			  }
			  for(int n=1;n<=a;n++)
			  {
				  System.out.print(" ");
			  }
			  for (int q = 4; q >= a; q--) 
				{
					System.out.print("*");
				}
			  

			System.out.println();
		}
	}

}
