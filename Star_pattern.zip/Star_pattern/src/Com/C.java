package Com;

public class C 
{
   public static void main(String[] args) 
   {
	  for(int i=1;i<=5;i++)
	  {
		  for(int j=5;i<=j;j--)
		  {
			  System.out.print(" ");
		  }
		  for(int x=1;x<=i;x++)
		  {
			  System.out.print("*");
		  }
		    System.out.println();
	  }
	   
}
}
