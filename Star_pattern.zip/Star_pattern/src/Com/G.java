package Com;

public class G
{
   public static void main(String[] args)
   {
	  for(int i=1;i<=5;i++)
	  {
		  for(int j=5;j>=i;j--)
		  {
			  System.out.print(" ");
		  }
		   for(int x=1;x<=i;x++)
		   {
			   System.out.print("*");
		   }
		   System.out.println();
	  }
	  for(int z=1;z<=5;z++)
	  {
		  for(int v=0;v<=z;v++)
		  {
			  System.out.print(" ");
		  }
		   for(int n=4;n>=z;n--)
		   {
			   System.out.print("*");
		   }
		   System.out.println();
	  }
}
}
